document.getElementById("image5").addEventListener("click", abrir);
document.getElementById("cerrar5").addEventListener("click", cerrar);
 
// Funcion que se ejecuta al pulsar el botón enviar el formulario
function abrir(e) {
	// Cancelams el envio a la espera de que valide el formulario
	e.preventDefault();
 
	// Mostramos la capa con el formulario de validacion
	document.getElementById("capa5").style.display="block";
	
}
 
// Funcion que se ejecuta al pulsar el boton Cancelar de cuadro de dialogo
function cerrar(e) {
	// Simplemente escondemkos el formulario
	document.getElementById("capa5").style.display="none";
}