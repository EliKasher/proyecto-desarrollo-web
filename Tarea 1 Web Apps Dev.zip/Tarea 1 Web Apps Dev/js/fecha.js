function fechaTermino(){
    var date = new Date();
    year = date.getFullYear();
    month = date.getMonth() + 1;
    day = date.getDate();
    hours = date.getHours(date.setHours(date.getHours() + 3));
    minutes = date.getMinutes();
    document.getElementById("dia-hora-termino").value = year + "-" + month + "-" + day + " " + hours + ":" + minutes;
}

function fechaInicio(){
    var date = new Date();
    year = date.getFullYear();
    month = date.getMonth() + 1;
    day = date.getDate();
    hours = date.getHours();
    minutes = date.getMinutes();
    document.getElementById("dia-hora-inicio").value = year + "-" + month + "-" + day + " " + hours + ":" + minutes;
}